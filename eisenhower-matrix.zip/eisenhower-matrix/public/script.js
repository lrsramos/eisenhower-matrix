class Task {
constructor(id, title, quadrant) {
    this.id = id;
    this.title = title;
    this.quadrant = quadrant;
    this.status = 'Backlog';
    this.progress = 0;
    this.dueDate = new Date().toISOString().split('T')[0];
    this.tags = [];
    this.completed = false;
    this.createdAt = new Date().toISOString();
    this.updatedAt = new Date().toISOString();
}
}

// API functions
async function fetchTasks() {
const response = await fetch('/api/tasks');
return await response.json();
}

async function createTask(task) {
const response = await fetch('/api/tasks', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(task),
});
return await response.json();
}

async function updateTask(taskId, updates) {
const response = await fetch(`/api/tasks/${taskId}`, {
    method: 'PUT',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(updates),
});
return await response.json();
}

async function deleteTask(taskId) {
await fetch(`/api/tasks/${taskId}`, {
    method: 'DELETE',
});
}

// UI functions
function createTaskElement(task) {
const taskElement = document.createElement('div');
taskElement.className = 'task';
taskElement.draggable = true;
taskElement.id = task.id;
taskElement.setAttribute('ondragstart', 'drag(event)');

taskElement.innerHTML = `
    <div class="task-header">
        <input type="checkbox" ${task.completed ? 'checked' : ''} 
               onchange="toggleTaskComplete('${task.id}')">
        <span>${task.title}</span>
        <div class="task-controls">
            <select onchange="updateTaskStatus('${task.id}', this.value)">
                <option value="Backlog" ${task.status === 'Backlog' ? 'selected' : ''}>Backlog</option>
                <option value="In Progress" ${task.status === 'In Progress' ? 'selected' : ''}>In Progress</option>
                <option value="Done" ${task.status === 'Done' ? 'selected' : ''}>Done</option>
            </select>
            <input type="date" value="${task.dueDate}"
                   onchange="updateDueDate('${task.id}', this.value)">
            <button onclick="deleteTaskById('${task.id}')">🗑️</button>
        </div>
    </div>
    <div class="progress-bar">
        <div class="progress" style="width: ${task.progress}%"></div>
    </div>
    <div class="task-tags">
        ${task.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
    </div>
`;

return taskElement;
}

async function addTask(quadrant) {
const title = prompt('Enter task title:');
if (title) {
    const task = new Task(`task-${Date.now()}`, title, quadrant);
    const savedTask = await createTask(task);
    const taskElement = createTaskElement(savedTask);
    document.querySelector(`#${quadrant} .tasks-container`).appendChild(taskElement);
}
}

async function updateTaskStatus(taskId, status) {
await updateTask(taskId, { 
    status, 
    updatedAt: new Date().toISOString() 
});
}

async function toggleTaskComplete(taskId) {
const taskElement = document.getElementById(taskId);
const checkbox = taskElement.querySelector('input[type="checkbox"]');
await updateTask(taskId, { 
    completed: checkbox.checked,
    updatedAt: new Date().toISOString()
});
}

async function updateDueDate(taskId, date) {
await updateTask(taskId, { 
    dueDate: date,
    updatedAt: new Date().toISOString()
});
}

async function deleteTaskById(taskId) {
if (confirm('Are you sure you want to delete this task?')) {
    await deleteTask(taskId);
    document.getElementById(taskId).remove();
}
}

function drag(event) {
event.dataTransfer.setData('text', event.target.id);
}

function allowDrop(event) {
event.preventDefault();
}

async function drop(event) {
event.preventDefault();
const taskId = event.dataTransfer.getData('text');
const newQuadrant = event.target.closest('.quadrant').id;

if (taskId && newQuadrant) {
    await updateTask(taskId, {
        quadrant: newQuadrant,
        updatedAt: new Date().toISOString()
    });
    
    const taskElement = document.getElementById(taskId);
    event.target.closest('.quadrant').querySelector('.tasks-container').appendChild(taskElement);
}
}

function showAnalytics() {
const modal = document.getElementById('analytics-modal');
const content = document.getElementById('analytics-content');

// Calculate analytics
const tasks = Array.from(document.querySelectorAll('.task'));
const total = tasks.length;
const completed = tasks.filter(task => task.querySelector('input[type="checkbox"]').checked).length;
const inProgress = tasks.filter(task => 
    task.querySelector('select').value === 'In Progress'
).length;

content.innerHTML = `
    <h3>Task Statistics</h3>
    <p>Total Tasks: ${total}</p>
    <p>Completed: ${completed}</p>
    <p>In Progress: ${inProgress}</p>
    <p>Completion Rate: ${Math.round((completed/total) * 100) || 0}%</p>
`;

modal.style.display = 'block';
}

// Close modal when clicking the X
document.querySelector('.close').onclick = function() {
document.getElementById('analytics-modal').style.display = 'none';
}

// Load tasks when page loads
async function loadTasks() {
const tasks = await fetchTasks();
tasks.forEach(task => {
    const taskElement = createTaskElement(task);
    document.querySelector(`#${task.quadrant} .tasks-container`).appendChild(taskElement);
});
}

window.onload = loadTasks;